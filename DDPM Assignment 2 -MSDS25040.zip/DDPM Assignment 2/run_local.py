import sys, json, os
W = "/kaggle/working/Assignment_2"
sys.path.insert(0, W); os.chdir(W)
import wandb
LOG = []
class _Img:
    def __init__(self, *a, **k): pass
def _log(d, *a, **k):
    fid = d.get("fid")
    LOG.append({"step": len(LOG) + 1, "loss": float(d["loss"]), "fid": None if fid is None else float(fid)})
wandb.login = lambda *a, **k: True
wandb.init = lambda *a, **k: None
wandb.finish = lambda *a, **k: None
wandb.Image = _Img
wandb.log = _log
from utils import train_diffusion
steps, every, data, folder, fid = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5] == "1"
train_diffusion(train_steps=steps, save_and_sample_every=every, fid=fid, save_folder=folder,
                data_path=data, dataloader_workers=2)
json.dump(LOG, open(folder + "/log.json", "w"))
print("local log saved:", len(LOG), "steps")
